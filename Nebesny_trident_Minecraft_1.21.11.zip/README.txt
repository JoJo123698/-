НЕБЕСНЫЙ ТРЕЗУБЕЦ — Minecraft Java 1.21.11

1. Скопируй папку/ZIP в resourcepacks и включи ресурс-пак.
2. Выдай предмет командой:

/give @s minecraft:stick[minecraft:item_model="breaksmp:trident_staff",minecraft:item_name='{"text":"Небесный трезубец","color":"aqua","italic":false}'] 1

Модель рассчитана на Minecraft Java 1.21.11.
